  #import modulB
#import modulB modulB
#import modulB modulB modulB

  #import modulC
  
#import 
#import modulB  
#import io/modulY

if (window['modulB$count'] === undefined)
    window['modulB$count'] = 0;
window['modulB$count'] = window['modulB$count'] +1;
