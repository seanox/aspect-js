
#import modulB
  #import modulB modulB
#import modulB modulB modulB

#import 
#import io/modulX
#import io/modulY

if (window['modulX$count'] === undefined)
    window['modulX$count'] = 0;
window['modulX$count'] = window['modulX$count'] +1;
