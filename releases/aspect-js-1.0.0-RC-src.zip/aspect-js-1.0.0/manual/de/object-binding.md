# Object Bindung

## Inhalt

* [Grundlagen](#grundlagen)
* [Begriffe](#begriffe)
  * [namespace](#namespace)
  * [scope](#scope)
  * [model](#model)
  * [field](#field)
  * [composite-id](#composite-id)
  * [identifier](#identifier)
* [Bindung](#bindung)
* [Synchronisation](#synchronisation)
* [Validierung](#validierung)

## Grundlagen

Bei der Objekt-Bindung geht es um die Verkn�pfung und Zuordnung von
HTML-Elementen, die das Attribut `composite` enthalten und zu denen
korrespondierende Model-Objekte im JavaScript existieren.


## Begriffe


### namespace

Der Namensraum ist eine Zeichen- bzw. Wortfolge, bestehend aus Buchstaben, Zahlen
sowie Unterstrich, welche die Verzweigung (Pfad) in einem Objekt-Baum
beschreibt. Als Trennzeichen wird der Punkt verwendet, er legt den �bergang von
einer zu n�chsten Ebene im Objekt-Baum fest.  
Jedes Element im Namensraum muss mindestens ein Zeichen enthalten, mit einem
Buchstaben beginnen und mit einem Buchstaben oder einer Zahl enden.

### scope

Der `scope` basiert auf `namespace` und repr�sentiert diesen auf der Objekt-Ebene.
Bedeutete der Namespace ist der beschreibende Text, der scope ist das Ergebnis, wenn der Namespace im Objekt-Baum aufgel�st wurde.

### model

Das Model (Model-Komponente / Komponente) ist ein statisches JavaScript-Objekt in einem
beliebigen namespace und stellt die Logik f�r die Benutzerschnittstelle
(UI-Komponente) und den �bergang von Benutzerschnittstelle zur Business-Logik
und/oder dem Backend bereit.  
Die Verkn�pfung bzw. Bindung von Markup und JavaSchript-Model �bernimmt die
Composite-API. Dazu muss ein HTML-Element mit dem Attribut `composite`
gekennzeichnet sein  und �ber eine g�ltige Composite-ID verf�gen. Die
Composite-ID muss dabei den Anforderungen vom namespace entsprechen.  
Weitere Details zur Objekt-, Feld- und Wert-Bindung werden im Abschnitt
[Bindung](#bindung) beschrieben.

Die Composite-API kann zwischen der Pr�sents und der Abwesenheit von
Model-Komponenten in der Benutzerschnittstelle durch die Existenz im DOM
unterscheiden. Die Model-Komponente wird beim Erscheinen im DOM �ber die
statische Methode `mount` und beim Entfernen aus dem DOM �ber die statische
Methode `unmount` informiert. Womit die Model-Komponente entsprechend vorbereitet
bzw. abgeschlossen werden kann.  
Die Implementierung beider Methoden ist optional.

```javascript
var model = {
    mount: function() {
    },
    unmount: function() {
    }
};
```

### field

Ein Feld ist die statische Eigenschaft einer statischen Model-Komponente. Es
korrespondiert mit einem HTML-Element mit gleichnamiger ID im gleichen
Namensraum. Die ID vom Feld kann relativ sein oder einen absoluten Namensraum
verwenden. Ist die ID relativ, wird der Namensraum durch das direkte
Composite-Eltern-Element festgelegt.

```html
<html>
  <body>
    <div id="model" composite>
      <input id="fieldA" type="text" events="change"/>
    </div>
  </body>
</html>
```

```javascript
var model = {
    fieldA: null
};
```

Die Composite-Komponente �bernimmt dann die einseitige und ereignisgesteuerte
Synchronisation zwischen dem HTML-Element und der Model-Komponenten-Eigenschaft.
F�r ein HTML-Element werden daf�r die entsprechenden Events �ber das
gleichnamige Attribut festgelegt.    


### composite-id

The Composite-ID is an application-wide unique identifier.  
It is a sequence of characters or words consisting of letters, numbers, and
underscores that contains at least one character, begins with a letter, and ends
with a letter or number. A Composite-ID is formed by combining the attributes
`ID` and `composite`.

```html
<html>
  <body>
    <div id="model" composite>
      ...
    </div>
  </body>
</html>
```
Die Composite-ID ist wichtig f�r MVC und wird zur Objekt-/Model-Bindung, die Synchronisation und Validierung ben�tigt. Auch SiteMap und der Renderer verwenden den eindeutigen Identifikator zur Erkennung und Steuerung von Model(-Komponenten).

Der Identifikator wird u.a. auch f�r den Face-Flow zur Erkennung und Steuerung von Faces und Factes sowie allgemein zur Erkennung und Steuerung von Model(-Komponenten) vewendet.

Es ist eine Zeichen- bzw. Wortfolge, bestehend aus Buchstaben, Zahlen sowie Unterstrich, die mindestens ein Zeichen enth�lt, mit eine Buchstaben beginnt und mit einem Buchstaben oder einer Zahl endet.
Eine Composite-ID entsteht mit der Kombination der Attribute ID und composite.


### identifier


## Bindung

Die Zuordnung und Verkn�pfung erfolgt �ber einen Namensraum (Namespace), auch
Scope bezeichnet -- Die Unterschiede zwischen Namensraum und Scope werden im
Abschnitt [Begriffe](#begriffe) erl�utert. Der Namensraum wird �ber die IDs der
HTML-Elemente im DOM relativ oder absolute abgebildet und verwendet den Punkt
als Trennzeichen.  
Ein relativer Namensraum verwendet keinen Punkt in der ID und wird durch die IDs
der Eltern-Elemente bis zum Wurzel-Element oder bis zum Auftreten der ersten ID
mit absolutem Namensraum, erweitert.  
Ein absoluter Namensraum ist �ber die ID voll qualifiziert und verwendet den
Punkt zur Trennung der einzelnen  Namensraum-Elemente.

Beispiel f�r einen relativen Namensraum `a.b.c`:

```html
<html>
  <body>
    <div id="a">
      <div id="b">
        <div id="c"></div>
      </div>
    </div>
  </body>
</html>
```

```javascript
var a = {
    b: {
        c: {}
    }
};
```

Beispiel f�r einen Mix von relativen und absoluten Namensraum `a.b` und `b.c.d`:

```html
<html>
  <body>
    <div id="a">
      <div id="b">
        <div id="b.c">
          <div id="d"></div>
        </div>
      </div>
    </div>
  </body>
</html>
```

```javascript
var a = {
    b: {
    }
};

var b = {
    c: {
        d: {}
    }
};
```


## Synchronisation

Neben der statischen Verkn�pfung und Zuordnung von HTML-Elementen zu
JavaScript-Modellen, umfasst die Objekt-Bindung auch die Synchronisation von
Werten zwischen den HTML-Elementen und den Feldern der JavaScript-Modelle.  
Die Synchronisation ist abh�ngig von Ereignisse, die beim HTML-Element mit 
dem  Attribut `events` festgelegt werden und somit wird die Synchronisation erst
mit dem Eintreten eines der festgelegten Ereignisse ausgef�hrt.

Details zur Verwendung werden im Abschnitt [events](markup.md#events)
beschrieben.  


## Validierung

Die Synchronisation von Werten zwischen den HTML-Elementen und den Feldern der
JavaScript-Modelle l�sst sich per Validierung kontrollieren und steuern.  
Die Verwendung der Validierung wird beim HTML-Element �ber das Attribut `validate`
festgelegt und erfordert das Attribut `events` sowie eine korrespondierende
validate-Methode im JavaScript-Model.

Details zur Verwendung werden im Abschnitt [validate](markup.md#validate)
beschrieben.
