#Datasource

TODO:
- XML basierte NoSQL-L�sung (read only)
- zus�tzliches Attribut "escaping" wandelt XSLT/Transformations-Output in HTML/XML um
  Sonst wird der Output automatisch maskiert, womit kein XML/HTML entsteht.
  default, wenn nicht angegeben: escaping = on/true/1
