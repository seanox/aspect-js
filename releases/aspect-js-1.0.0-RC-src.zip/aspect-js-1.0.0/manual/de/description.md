# Beschreibung

Seanox aspect-js ist ein JavasScript-Framework zur Implementierung dynamischer
Oberfl�chen f�r Web-Browser.

Das Framework greift den deklarativen Ansatz von HTML auf und verbindet Markup
und JavaScript �ber den Model-View-Controler zu Komponenten, die direkt oder
�ber virtuelle Pfade angesprochen werden.  
Dynamischen Inhalten stellt das Framework im Markup und als Freitext eine auf
JavaScript basierende Expression-Language sowie ein erweitertes JavaScript-API
bereit.


## Komponenten
TODO:

### Composite


### DataSource


### Extension


### Messages


### Model View Controler


### Test
