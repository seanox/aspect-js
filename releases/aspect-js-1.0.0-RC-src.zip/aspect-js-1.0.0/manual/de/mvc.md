--------------------------------------

Der Model View Controler (MVC) ist ein Entwurfsmuster zur Trennung von Interaktion, Daten und Darstellung.


Controler:
Hier muss man zwischen I/O-Controller und Applikations-Controller unterscheiden.
Das reine MVC-Entwurfsmuster meint den I/O-Controller zur �bermittlung der Interaktionen.
Da dieser durch Betrieb(s)system und Browser bereitgestellt wird, bezieht sich der Controler in aspect-js vordergr�ndig auf den Applikations-Controller.
Der Applikations-Controller steuert die Abl�ufe innerhalb einer Applikation (Face-Flow), �bernimmt das Binding von Markup und JavaScript sowie die Steuerung vom Datenfluss zwischen View und Model.




Modell:

Das Modell ist ein darstellbares/projezierbares Objekt.
Es empf�ngt (Status)�nderungen und Interaktionen der View, die durch den Controler �bermittelt werden, bzw. bietet der View eine Schnittstelle zu Daten sowie Funktionen und Diensten der Middelware.
Das Modell dient vorrangig der View zur Darstellung und Verwaltung der Zust�nde, f�r fachliche Funktionalit�t nimmt es weitere Komponenten in Anspruch.
In aspect-js werden die Modelle durch statische JavaScript-Objekte repr�sentiert.
Konzeptionell ist die Implementierung der Entwurfsmuster Fassade und Delegation angedacht, so dass die statischen Modelle intern weitere Komponenten und Abstraktion verwenden.







View:
Die View ist ausschliesslich f�r die Darstellung bzw. Projektion eines Modells verantwortlich.
Projektion ist ein wichtiger Begriff, da die Art der Darstellung eines Models nicht eingeschr�nkt ist.
In aspect-js werden die Views durch das Markup repr�sentiert.


Ereignisse, genauer gesagt die Interaktion zwischen View und Model, werden beim Objekt-/Model-Binding ebenfalls ber�cksichtigt.
Die Methoden f�r die Interaktion werden ausschliesslich im Model implementiert.
Im Markup selbst ist keine Deklaration erforderlich.
Das Objekt-/Model-Binding kennt die f�r HTML verf�gbaren Events.
Beim Binding wird das Model nach korrespondierenden on-Methoden durchsucht und als Event-Listener registriert.




Die Pr�sentation in aspect-js ist mehrschichtig und die Views sind als Page, Faces und Facets organisiert.
Hierf�r stellt die SiteMap eine verzweigte Verzeichnisstruktur �ber alle Views bereit.
Die einzelnen Views werden �ber virtuelle Pfade angesprochen.
Die SiteMap kontrolliert dann den Zugriff und steuert die Anzeige der Views.



-----------------------------




#MVC

## Inhalt

* [SiteMap](#sitemap)
* [Path](#path)
  * [Acceptor](#acceptor)

## SiteMap

Die SiteMap ist eine statische Navigationskomponente, basierend auf virtuellen
Pfaden und Views. Virtuelle Pfade dienen zur Abgrenzung von Seiten und zur
Fokussierung von Projektionen. Seiten sind eine (komplexe) Ansicht und
kombinieren u.a. verschiedenen feste Inhalte (Navigation,  Menu, Footer, ...)
sowie variable Projektionen (Faces / Views), die wiederum Unter- und
Teil-Projektionen (Facets) verwenden k�nnen.

Virtuelle Pfade verwenden eine URL-Hash-Navigation, bei der das Hash-Zeichen als
Trennung der einzelnen Pfadteile benutzt wird. Die SiteMap �berwacht den
URL-Hash und die Verwendung der virtuellen Pfade aktiv in Punkto G�ltigkeit und
Berechtigung.

Eine sehr spezielle Funktion bei der Navigation �bernehmen Acceptoren.  
Acceptoren k�nnen als Pfadfilter betrachtet werden. Sie basieren auf regul�ren
Ausdr�cken und Methoden die bei Entsprechung der Pfade zu einem Muster
ausgef�hrt werden. Acceptoren k�nnen still im Hintergrund arggieren, ohne
Einfluss auf die Navigation der SiteMap zu nehmen, oder sie aktiv und �bernehmen
die Navigation komplett aktiv oder passiv durch Weiterleitung
(Ver�nderung/Manipulation vom Ziel). 

Alles in allem ist die SiteMap mit einem Stadtplan vergleichbar. Die Pfade sind
Strassen und bilden durch Verkettung eine Route von der Wurzel zum Ziel. Das
Ziel kann eine Strasse (Face) sein, womit alle Adressen/Sehensw�rdigkeiten
(Views) angezeigt werden oder das Ziel ist eine konkrete
Adresse/Sehensw�rdigkeit (View) in einer Strasse.

Alle Strassen besitzen einen W�chter, dieser kann entsprechend von
Berechtigungen den Zugang zur Strasse und/oder einzelnen
Adressen/Sehensw�rdigkeiten verbieten und erlauben.

F�r Strassen, Adressen/Sehensw�rdigkeiten lassen sich Muster einrichten, welche
aktiv den Verlauf der Route �ndern oder passiv den Verlauf der Route verfolgen. 
  

### Path

### Acceptor

Ein Acceptor ist eine spezielle funktionale Form eines virtuellen Pfades.  
Der Acceptor setzt sich aus einem Regul�ren Ausdruck (Pattern) und einer
Funktion zusammen und wird mit SiteMap-Struktur �ber die Methode
SiteMap.customize(structur) festgelegt.  

Bei der Navigation �ber die SiteMap werden allen registrierten Acceptoren
durchlaufen. Entspricht der angeforderte Pfad dem Pattern eines Acceptor, wird
dessen Methode aufgerufen.
  
Beim R�ckgabewert false, wird die Navigation der Acceptor-Methode �berlassen und
die
Navigation wird von der SiteMap abgebrochen, weitere Acceptoren werden nicht
durchlaufen.  

Beim R�ckgabewert String, wird der R�ckgabewert als neues Ziel festgelegt zu der
die SiteMap dann navigiert (normales Verhalten). Weitere Acceptoren werden mit
der nicht durchlaufen.  

Bei allen anderen R�ckgabewerten, werden die weiteren Acceptoren durchlaufen und
der angeforderte Pfad mit deren Pattern verglichen.
