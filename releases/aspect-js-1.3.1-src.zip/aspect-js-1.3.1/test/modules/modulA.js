  #import modulB
  #import modulB modulB
  #import modulB modulB modulB
  
#import 
#import modulA  
#import io/modulY

if (window['modulA$count'] === undefined)
    window['modulA$count'] = 0;
window['modulA$count'] = window['modulA$count'] +1;
