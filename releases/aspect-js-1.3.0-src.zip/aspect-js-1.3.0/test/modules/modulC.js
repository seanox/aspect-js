
#import modulB
  #import modulB modulB
#import modulB modulB modulB

#import 
#import io/modulX
  
#import 
#import modulC
#import io/modulY

if (window['modulC$count'] === undefined)
    window['modulC$count'] = 0;
window['modulC$count'] = window['modulC$count'] +1;
